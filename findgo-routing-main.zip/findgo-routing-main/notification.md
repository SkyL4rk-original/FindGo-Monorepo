-> check for new featured specials

* get all companies uuid user has notify on for (from post req for now, move to from db later)
* get date last check

* get all fatured specials activated after last check time
