package app.specials.findgo_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
