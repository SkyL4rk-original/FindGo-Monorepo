// import 'package:internet_connection_checker/internet_connection_checker.dart';

// abstract class NetworkInfoContract {
//   Future<bool> get isConnected;
// }

// MOBILE
class NetworkInfo {
  // final InternetConnectionChecker internetConnectionChecker;

  // NetworkInfo(this.internetConnectionChecker);

  // Future<bool> get isConnected => internetConnectionChecker.hasConnection;

  Future<bool> get isConnected async => true;

}